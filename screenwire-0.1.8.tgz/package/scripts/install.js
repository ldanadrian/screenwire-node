'use strict'

const fs = require('fs')
const path = require('path')
const { execSync } = require('child_process')

const binary = path.join(__dirname, '..', 'build', 'Release', 'screenwire.node')
const windowsDll = path.join(__dirname, '..', 'builds', 'windows', 'ScreenWireWindows.dll')

if (fs.existsSync(binary)) {
  process.exit(0)
}

if (process.platform === 'darwin') {
  execSync('node scripts/build.js', {
    cwd: path.join(__dirname, '..'),
    stdio: 'inherit'
  })
  process.exit(0)
}

if (process.platform === 'win32') {
  if (!fs.existsSync(windowsDll)) {
    throw new Error(
      'Missing bundled Windows backend DLL at bindings/node/builds/windows/ScreenWireWindows.dll. ' +
      'Build it before packaging with: npm run build:windows:dll'
    )
  }

  execSync('node-gyp rebuild', {
    cwd: path.join(__dirname, '..'),
    stdio: 'inherit'
  })
  process.exit(0)
}

throw new Error(`Unsupported platform: ${process.platform}`)
